const DEFAULTS={enabled:true,boost:100,voice:false,bass:false};

const clamp=(n,min,max)=>Math.min(max,Math.max(min,n));

const qs=id=>document.getElementById(id);
const toggle=(el,v)=>el.classList.toggle("on",!!v);

 function bindToggle(el,key,s){
  el.addEventListener("click",async()=>{
   s[key]=!s[key];
   toggle(el,s[key]);
   await save(s);
   await send(s);
  });
 }


async function load(){
 const s=await chrome.storage.local.get(DEFAULTS);
 return {...DEFAULTS,...s};
}
async function save(s){await chrome.storage.local.set(s);}
async function send(s){
 const [t]=await chrome.tabs.query({active:true,currentWindow:true});
 if(t?.id) chrome.tabs.sendMessage(t.id,{type:"NAVINE_SETTINGS",payload:s});
}

document.addEventListener("DOMContentLoaded",async()=>{
 let s=await load();
 const els={
  enabled:qs("enabled"),
  voice:qs("voice"),
  bass:qs("bass"),
  boost:qs("boost"),
  boostInput:qs("boostInput"),
  reset:qs("reset")
 };

 for(const k of ["enabled","voice","bass"]) toggle(els[k],s[k]);
 const setBoostUI=(v)=>{
  const vv=clamp(Number(v)||0,0,99999);
  els.boost.value=String(vv);
  if(els.boostInput) els.boostInput.value=String(vv);
 };
 setBoostUI(s.boost);

 const bind=(k)=>{
  els[k].onclick=async()=>{
   s[k]=!s[k]; toggle(els[k],s[k]);
   await save(s); send(s);
  };
 };
 bind("enabled"); bind("voice"); bind("bass");

 // Slider -> number input
 els.boost.oninput=()=>{
  if(els.boostInput) els.boostInput.value=els.boost.value;
 };
 els.boost.onchange=async()=>{
  s.boost=clamp(+els.boost.value,0,99999);
  setBoostUI(s.boost);
  await save(s); send(s);
 };

 // Number input -> slider (type any %)
 if(els.boostInput){
  const commit=async()=>{
   s.boost=clamp(+els.boostInput.value,0,99999);
   setBoostUI(s.boost);
   await save(s); send(s);
  };
  els.boostInput.addEventListener("input",()=>{
   // live sync slider while typing (no save until change/enter/blur)
   const v=clamp(+els.boostInput.value,0,99999);
   els.boost.value=String(v);
  });
  els.boostInput.addEventListener("change",commit);
  els.boostInput.addEventListener("blur",commit);
  els.boostInput.addEventListener("keydown",(e)=>{
   if(e.key==="Enter") { e.preventDefault(); els.boostInput.blur(); }
  });
 }

 els.reset.onclick=async()=>{
  s={...DEFAULTS};
  await save(s); location.reload(); send(s);
 };

 send(s);
});

async function updateTabs(){
 const tabs=await chrome.tabs.query({});
 const active=[];
 for(const t of tabs){
  try{
   await chrome.tabs.sendMessage(t.id,{type:"NAVINE_PING"});
   active.push(t.title||"Tab "+t.id);
  }catch{}
 }
 const el=document.getElementById("tabs");
 if(el) el.textContent=active.length?active.join("\n"):"None";
}
updateTabs();
