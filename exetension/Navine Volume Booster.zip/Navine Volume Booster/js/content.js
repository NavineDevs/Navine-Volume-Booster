(()=>{

const DEFAULTS={enabled:true,boost:100,voice:false,bass:false};
let state={...DEFAULTS};
let ctx;
const wired=new WeakMap();

const gainFromBoost=b=>Math.max(1, b/100);

async function load(){
 try{
  const s=await chrome.storage.local.get(DEFAULTS);
  state={...DEFAULTS,...s};
 }catch{}
}

function ensureCtx(){
 if(ctx && ctx.state!=="closed") return ctx;
 ctx=new (window.AudioContext||window.webkitAudioContext)();
 return ctx;
}

function wire(el){
 if(wired.has(el)) return;
 if(!(el instanceof HTMLMediaElement)) return;

 const c=ensureCtx();
 const src=c.createMediaElementSource(el);
 const gain=c.createGain();

 const low=c.createBiquadFilter();
 low.type="lowshelf"; low.frequency.value=200;

 const mid=c.createBiquadFilter();
 mid.type="peaking"; mid.frequency.value=1400; mid.Q.value=1;

 src.connect(low).connect(mid).connect(gain).connect(c.destination);
 wired.set(el,{gain,low,mid});
}

function apply(){
 document.querySelectorAll("audio,video").forEach(el=>{
  wire(el);
  const w=wired.get(el);
  if(!w) return;

  if(!state.enabled){
   w.gain.gain.value=1;
   w.low.gain.value=0;
   w.mid.gain.value=0;
   el.volume=1;
   return;
  }

  const b=state.boost;
  el.volume=b<=100?b/100:1;
  w.gain.gain.value=gainFromBoost(b);

  w.low.gain.value=state.bass?8:0;
  w.mid.gain.value=state.voice?6:0;
 });
}

chrome.runtime.onMessage.addListener(m=>{
 if(m?.type==="NAVINE_PING"){return;}

 if(m?.type==="NAVINE_SETTINGS"){
  state={...state,...m.payload};
  apply();
 }
});

(async()=>{
 await load();
 const obs=new MutationObserver(apply);
 obs.observe(document,{childList:true,subtree:true});
 apply();
})();
})();